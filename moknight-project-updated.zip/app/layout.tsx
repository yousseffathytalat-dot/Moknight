import "./globals.css";
import Providers from "@/components/Providers";

export const metadata = {
  title: "MoKnight",
  description: "Video Editor & Motion Graphics Designer",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
